#pragma once

// Note: Update the version when release a new version.

// IGUANA_VERSION % 100 is the sub-minor version
// IGUANA_VERSION / 100 % 1000 is the minor version
// IGUANA_VERSION / 100000 is the major version
#define IGUANA_VERSION 100005  // 1.0.5