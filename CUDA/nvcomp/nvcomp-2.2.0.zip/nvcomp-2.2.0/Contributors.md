# NVCOMP Developers and Contributors

This is the official list of NVCOMP developers and contributors.

## DEVELOPERS
Nikolay Sakharnykh  
Dominique Lasalle  
Ben Karsin  
Akshay Subramaniam  
Guillaume Thomas-Collignon  
Xavier Simmons  
Mengran Fan  
Hao Gao  
Maxim Milakov  
Markus Tavenrath  
Eric Schmidt  
Neil Dickson  

## NVCOMP Product Manager
Matthew Nicely
  
## CONTRIBUTORS
Jason Newton  
Robert Underwood  
Robert Maynard  
Jason Lowe  

## ACKNOWLEDGEMENTS
