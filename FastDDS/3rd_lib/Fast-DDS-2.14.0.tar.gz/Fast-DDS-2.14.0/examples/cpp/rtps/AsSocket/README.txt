To launch this test open two different consoles:

In the first one launch: ./AsSocket reader (or AsSocket.exe reader on windows).
In the second one: ./AsSocket writer (or AsSocket.exe writer on windows).
