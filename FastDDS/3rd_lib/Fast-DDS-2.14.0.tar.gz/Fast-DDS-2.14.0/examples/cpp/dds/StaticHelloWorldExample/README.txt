To launch this test open two different consoles:

In the first one launch: ./DDSStaticHelloWorldExample publisher (or DDSStaticHelloWorldExample.exe publisher on windows).
In the second one: ./DDSStaticHelloWorldExample subscriber (or DDSStaticHelloWorldExample.exe subscriber on windows).

Note: This example needs the xml file stored in the sources directory. You need to copy this folder where you will execute the example executable. The CMakeList.txt file also copies this file to the folder used to build the example.
