This example needs the certificates stored in "certs" directory. You need to
copy this folder where you will execute the example executable. The
CMakeList.txt file also copies this directory to the folder used to build the
example.

To launch this test open two different consoles:

In the first one launch: ./DDSSecureHelloWorldExample publisher (or DDSSecureHelloWorldExample.exe publisher on windows).
In the second one: ./DDSSecureHelloWorldExample subscriber (or DDSSecureHelloWorldExample.exe subscriber on windows).

