#!/usr/bin/env python3
import sqlite3
import gzip
import math
import sys
import re

def xyz_to_latlon(z, x, y_tms):
    """将 MBTiles 的 Z/X/Y (TMS) 转换为经纬度坐标"""
    # MBTiles 使用 TMS 坐标系，MapLibre/Google 使用 XYZ 坐标系
    # 需要翻转 Y 轴
    y_xyz = (1 << z) - 1 - y_tms
    n = 2.0 ** z
    lon_deg = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y_xyz / n)))
    lat_deg = math.degrees(lat_rad)
    return lat_deg, lon_deg

def search_mbtiles(db_path, keyword):
    print(f"正在读取文件: {db_path}")
    print(f"正在搜索关键字: '{keyword}'...")
    
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        cursor = conn.cursor()

        # 1. 获取最大缩放级别（通常包含最详细的地名）
        cursor.execute("SELECT MAX(zoom_level) FROM tiles")
        max_zoom = cursor.fetchone()[0]
        print(f"地图最大缩放级别为: {max_zoom}")

        # 2. 扫描所有瓦片
        # 我们优先扫描最高两个级别，因为地名最全
        cursor.execute(
            "SELECT zoom_level, tile_column, tile_row, tile_data FROM tiles WHERE zoom_level >= ?", 
            (max_zoom - 1,)
        )

        found_results = []
        search_pattern = keyword.encode('utf-8')

        for z, x, y, data in cursor:
            try:
                # 处理 PBF 瓦片的解压 (MBTiles 中的 PBF 通常是 GZIP 压缩的)
                if data.startswith(b'\x1f\x8b'):
                    data = gzip.decompress(data)
                
                # 在二进制流中快速查找
                if search_pattern in data:
                    # 使用正则提取包含关键字的 UTF-8 字符串
                    # \x00-\x1f 是 PBF 的控制字符，排除它们以提取干净的文本
                    matches = re.findall(rb'([^\x00-\x1f]{0,20}' + re.escape(search_pattern) + rb'[^\x00-\x1f]{0,20})', data)
                    
                    if matches:
                        lat, lon = xyz_to_latlon(z, x, y)
                        for m in matches:
                            try:
                                name = m.decode('utf-8')
                                result = {
                                    "name": name,
                                    "lat": lat,
                                    "lon": lon,
                                    "zoom": z
                                }
                                # 去重：如果同一个瓦片有多个相同的匹配，只记一次
                                if result not in found_results:
                                    found_results.append(result)
                            except UnicodeDecodeError:
                                continue
            except Exception:
                continue

        conn.close()

        # 3. 输出结果
        if not found_results:
            print("未找到任何匹配结果。")
        else:
            print(f"\n找到 {len(found_results)} 个匹配项：")
            print("-" * 60)
            print(f"{'地名':<30} | {'纬度':<10} | {'经度':<10}")
            print("-" * 60)
            for res in found_results:
                print(f"{res['name']:<30} | {res['lat']:<10.6f} | {res['lon']:<10.6f}")
            print("-" * 60)

    except sqlite3.Error as e:
        print(f"数据库错误: {e}")
    except Exception as e:
        print(f"发生错误: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python3 search_mbtiles.py <mbtiles文件> <关键词>")
        print("示例: python3 search_mbtiles.py beijing.mbtiles 抖音")
    else:
        search_mbtiles(sys.argv[1], sys.argv[2])
