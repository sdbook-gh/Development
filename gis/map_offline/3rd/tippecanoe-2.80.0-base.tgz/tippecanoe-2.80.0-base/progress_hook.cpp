#include "progress_hook.h"

#include <atomic>
#include <cstdio>

static tippecanoe_progress_cb g_progress_cb = 0;
static std::atomic<size_t> g_join_done{0};
static size_t g_join_total = 0;

extern "C" void tippecanoe_set_progress_callback(tippecanoe_progress_cb cb) {
	g_progress_cb = cb;
}

extern "C" void tile_join_set_progress_callback(tippecanoe_progress_cb cb) {
	g_progress_cb = cb;
}

extern "C" void tile_join_ext_set_progress_callback(tippecanoe_progress_cb cb) {
	g_progress_cb = cb;
}

extern "C" void tippecanoe_report_progress(int percent, const char *stage) {
	if (g_progress_cb) {
		g_progress_cb(percent, stage);
	}
}

extern "C" void tile_join_progress_reset(size_t total) {
	g_join_total = total;
	g_join_done = 0;
}

extern "C" void tile_join_progress_tile(long long z, long long x, long long y) {
	size_t done = ++g_join_done;
	int pct = g_join_total > 0 ? static_cast<int>(100 * done / g_join_total) : -1;
	char stage[64];
	snprintf(stage, sizeof(stage), "z%lld/%lld/%lld", z, x, y);
	tippecanoe_report_progress(pct, stage);
}
