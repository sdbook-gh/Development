/*
 * exit_util.cpp - implementation of the fd registry + run guard.
 *
 * The intercept macros from exit_util.h are #undef'd here so the wrappers
 * can call the real libc functions (whose declarations were already parsed
 * by exit_util.h before the macros were defined).
 */

#include "exit_util.h"

#undef open
#undef close
#undef fopen
#undef fclose
#undef fdopen
#undef mkstemp
#undef dup
#undef pipe
#undef exit
#ifdef __ANDROID__
#undef fprintf
#undef printf
#undef perror
#endif

#include <atomic>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <stdarg.h>
#include <string.h>
#include <time.h>

jmp_buf g_tc_exit_jmp;
int g_tc_exit_code = 0;

namespace {

struct fd_record {
	uint64_t run_id;
	const char *file;
	int line;
	std::string path;
};

std::mutex g_fd_mtx;
std::unordered_map<int, fd_record> g_fd_map;
std::atomic<uint64_t> g_run_counter{0};
std::atomic<uint64_t> g_current_run{0};

void tc_copy_path(char *dst, size_t dst_sz, const char *src) {
	if (dst_sz == 0) {
		return;
	}
	if (src == NULL || src[0] == '\0') {
		dst[0] = '?';
		dst[1] = '\0';
		return;
	}
	strncpy(dst, src, dst_sz - 1);
	dst[dst_sz - 1] = '\0';
}

void tc_fd_register(int fd, uint64_t run_id, const char *file, int line, const char *path) {
	if (fd < 0) {
		return;
	}
	std::lock_guard<std::mutex> lk(g_fd_mtx);
	fd_record rec;
	rec.run_id = run_id;
	rec.file = file;
	rec.line = line;
	rec.path = (path != NULL && path[0] != '\0') ? path : "?";
	g_fd_map[fd] = std::move(rec);
}

void tc_fd_unregister(int fd) {
	if (fd < 0) {
		return;
	}
	std::lock_guard<std::mutex> lk(g_fd_mtx);
	g_fd_map.erase(fd);
}

void tc_log(int level, const char *fmt, ...) {
	char buf[2048];
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(buf, sizeof(buf), fmt, ap);
	va_end(ap);
#ifdef __ANDROID__
	tippecanoe_logf(level, "%s", buf);
#else
	(void)level;
	fputs(buf, stderr);
	fflush(stderr);
#endif
}

void tc_log_fd_record(int level, int fd, fd_record const &rec) {
	tc_log(level, "  fd=%d path=%s opened at %s:%d\n",
	       fd,
	       rec.path.empty() ? "?" : rec.path.c_str(),
	       rec.file ? rec.file : "?",
	       rec.line);
}

}  // namespace

extern "C" uint64_t tc_run_begin(void) {
	struct timespec ts;
#ifdef CLOCK_MONOTONIC
	clock_gettime(CLOCK_MONOTONIC, &ts);
#else
	ts.tv_sec = 0;
	ts.tv_nsec = 0;
#endif
	uint64_t ns = (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
	uint64_t c = g_run_counter.fetch_add(1, std::memory_order_relaxed) + 1;
	uint64_t id = (ns << 8) | (c & 0xFF);
	g_current_run.store(id, std::memory_order_release);
	return id;
}

extern "C" void tc_run_end(uint64_t run_id, int report) {
	std::vector<std::pair<int, fd_record>> leaked;
	{
		std::lock_guard<std::mutex> lk(g_fd_mtx);
		for (auto it = g_fd_map.begin(); it != g_fd_map.end();) {
			if (it->second.run_id == run_id) {
				leaked.push_back(*it);
				it = g_fd_map.erase(it);
			} else {
				++it;
			}
		}
	}

	if (report && !leaked.empty()) {
		tc_log(2, "tippecanoe: %zu file descriptor(s) not closed (run %llu):\n",
		       leaked.size(), (unsigned long long)run_id);
		for (auto const &p : leaked) {
			tc_log_fd_record(2, p.first, p.second);
		}
	}

	/* Close leaked descriptors so they do not accumulate across runs when
	 * tippecanoe is run in-process (Android JNI). */
	for (auto const &p : leaked) {
		close(p.first);
	}
}

tc_run_guard::~tc_run_guard() {
	tc_run_end(rid, 1);
}

extern "C" void tc_fd_forget(int fd) {
	tc_fd_unregister(fd);
}

extern "C" int tc_fd_snapshot(tc_fd_info *out, int out_cap) {
	if (out == NULL || out_cap <= 0) {
		return 0;
	}
	uint64_t rid = g_current_run.load(std::memory_order_relaxed);
	int n = 0;
	std::lock_guard<std::mutex> lk(g_fd_mtx);
	for (auto const &p : g_fd_map) {
		if (p.second.run_id != rid) {
			continue;
		}
		if (n >= out_cap) {
			break;
		}
		out[n].fd = p.first;
		out[n].file = p.second.file;
		out[n].line = p.second.line;
		tc_copy_path(out[n].path, sizeof(out[n].path), p.second.path.c_str());
		n++;
	}
	return n;
}

extern "C" int tc_fd_dump_new(const tc_fd_info *before, int n_before, const tc_fd_info *after, int n_after) {
	std::unordered_set<int> before_fds;
	before_fds.reserve(n_before > 0 ? (size_t)n_before : 1);
	for (int i = 0; i < n_before; i++) {
		before_fds.insert(before[i].fd);
	}

	int found = 0;
	for (int i = 0; i < n_after; i++) {
		if (before_fds.find(after[i].fd) != before_fds.end()) {
			continue;
		}
		if (found == 0) {
			tc_log(2, "tippecanoe: tippecanoe-owned FD(s) still open after reading input:\n");
		}
		tc_log(2, "  fd=%d path=%s opened at %s:%d\n",
		       after[i].fd,
		       after[i].path[0] ? after[i].path : "?",
		       after[i].file ? after[i].file : "?",
		       after[i].line);
		found++;
	}
	if (found == 0) {
		tc_log(1, "tippecanoe: no tippecanoe-owned FD delta after reading input\n");
	}
	return found;
}

extern "C" void tc_fd_dump_proc_between(int fd_lo, int fd_hi) {
	if (fd_hi <= fd_lo) {
		return;
	}
	tc_log(1, "tippecanoe: /proc/self/fd in [%d, %d):\n", fd_lo, fd_hi);
	for (int fd = fd_lo; fd < fd_hi; fd++) {
		char linkpath[64];
		char target[TC_FD_PATH_MAX];
		snprintf(linkpath, sizeof(linkpath), "/proc/self/fd/%d", fd);
		ssize_t n = readlink(linkpath, target, sizeof(target) - 1);
		if (n < 0) {
			tc_log(1, "  fd=%d <unavailable: %s>\n", fd, strerror(errno));
			continue;
		}
		target[n] = '\0';
		tc_log(1, "  fd=%d -> %s\n", fd, target);
	}

	/* Also list any tippecanoe-owned records for those fds (open site). */
	std::lock_guard<std::mutex> lk(g_fd_mtx);
	for (int fd = fd_lo; fd < fd_hi; fd++) {
		auto it = g_fd_map.find(fd);
		if (it == g_fd_map.end()) {
			continue;
		}
		tc_log(1, "  fd=%d registry path=%s opened at %s:%d\n",
		       fd,
		       it->second.path.empty() ? "?" : it->second.path.c_str(),
		       it->second.file ? it->second.file : "?",
		       it->second.line);
	}
}

extern "C" int tc_open(const char *file, int line, const char *path, int flags, ...) {
	int fd;
	if (flags & O_CREAT) {
		va_list ap;
		va_start(ap, flags);
		int mode = va_arg(ap, int); /* mode_t is promoted to int in ... */
		va_end(ap);
		fd = open(path, flags, mode);
	} else {
		fd = open(path, flags);
	}
	if (fd >= 0) {
		tc_fd_register(fd, g_current_run.load(std::memory_order_relaxed), file, line, path);
	}
	return fd;
}

extern "C" int tc_close(const char *file, int line, int fd) {
	(void)file;
	(void)line;
	tc_fd_unregister(fd);
	return close(fd);
}

extern "C" FILE *tc_fopen(const char *file, int line, const char *path, const char *mode) {
	FILE *fp = fopen(path, mode);
	if (fp != NULL) {
		int fd = fileno(fp);
		if (fd >= 0) {
			tc_fd_register(fd, g_current_run.load(std::memory_order_relaxed), file, line, path);
		}
	}
	return fp;
}

extern "C" int tc_fclose(const char *file, int line, FILE *fp) {
	(void)file;
	(void)line;
	if (fp != NULL) {
		int fd = fileno(fp);
		tc_fd_unregister(fd);
	}
	return fclose(fp);
}

extern "C" FILE *tc_fdopen(const char *file, int line, int fd, const char *mode) {
	(void)file;
	(void)line;
	/* fdopen does not create a new descriptor; fd was already registered by
	 * its creator (open/mkstemp/dup/pipe). The later fclose() will unregister
	 * the underlying fd. */
	return fdopen(fd, mode);
}

extern "C" int tc_mkstemp(const char *file, int line, char *name) {
	int fd = mkstemp(name);
	if (fd >= 0) {
		/* mkstemp rewrites name to the concrete path. */
		tc_fd_register(fd, g_current_run.load(std::memory_order_relaxed), file, line, name);
	}
	return fd;
}

extern "C" int tc_dup(const char *file, int line, int oldfd) {
	int fd = dup(oldfd);
	if (fd >= 0) {
		tc_fd_register(fd, g_current_run.load(std::memory_order_relaxed), file, line, "<dup>");
	}
	return fd;
}

extern "C" int tc_pipe(const char *file, int line, int fds[2]) {
	int rc = pipe(fds);
	if (rc == 0) {
		uint64_t rid = g_current_run.load(std::memory_order_relaxed);
		tc_fd_register(fds[0], rid, file, line, "<pipe>");
		tc_fd_register(fds[1], rid, file, line, "<pipe>");
	}
	return rc;
}
