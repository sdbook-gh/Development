#pragma once

#ifdef __ANDROID__

#include "log_hook.h"

#include <errno.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern jmp_buf g_tc_exit_jmp;
extern int g_tc_exit_code;

#ifdef __cplusplus
#include <cstdlib>
#include <exception>
#include <string>

class TippecanoeExitException : public std::exception {
public:
	int _code;
	std::string _file;
	int _line;
	explicit TippecanoeExitException(int code, std::string const &file = "", int line = 0)
	    : _code(code), _file(file), _line(line) {}
	const char *what() const noexcept override {
		return "tippecanoe exit";
	}
};

#define exit(code) throw TippecanoeExitException(code, __FILE__, __LINE__)
#else
#define exit(code) (g_tc_exit_code = (code), longjmp(g_tc_exit_jmp, 1))
#endif

#define fprintf(fp, fmt, ...) tippecanoe_logf(1, fmt, ##__VA_ARGS__)
#define printf(fmt, ...) tippecanoe_logf(0, fmt, ##__VA_ARGS__)
#define perror(str) tippecanoe_logf(2, "perror: %s: %s", str, strerror(errno))

#endif /* __ANDROID__ */
