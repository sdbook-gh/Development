#pragma once
#ifndef EXIT_UTIL_H
#define EXIT_UTIL_H

/*
 * exit_util.h — force-injected header (Android + desktop fd-leak validation).
 *
 * Active when building for Android (__ANDROID__) or for the desktop
 * validation build (TIPPECANOE_VALIDATE). In both modes:
 *   - `exit()` is redirected so the entry-point run guard still runs:
 *       C++ : throw TippecanoeExitException(code, file, line)
 *       C   : longjmp back to the entry point (set up by the caller)
 *   - file descriptor creating/closing libc calls (open, close, fopen,
 *     fclose, fdopen, mkstemp, dup, pipe) are redirected to tc_* wrappers
 *     that maintain a global fd registry tagged with a per-run id. Each
 *     registration stores the open site (file:line) and path so leaks can
 *     be attributed. At run end, any fd still registered for that run is
 *     reported and closed.
 * On Android additionally stderr output (fprintf/printf/perror) is routed
 * through the log hook.
 *
 * IMPORTANT: the system headers that declare the intercepted functions are
 * included below BEFORE the macros are defined, so their declarations are
 * parsed verbatim and not rewritten by the macros. TUs that subsequently
 * re-include them hit the usual include guards (no-op).
 *
 * NOTE: because `open`/`close` are redefined as function-like macros, no TU
 * may USE std::fstream objects (whose member calls `.open()`/`.close()` would
 * be mangled). All fstream usage has been converted to plain FILE* / raw fd.
 * <locale> and <fstream> are pre-included above (declarations only) so their
 * member open()/close() declarations parse before the macros.
 */

#if defined(__ANDROID__) || defined(TIPPECANOE_VALIDATE)

#ifdef __ANDROID__
#include "log_hook.h"
#endif

#include <errno.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdint.h>

extern jmp_buf g_tc_exit_jmp;
extern int g_tc_exit_code;

#ifdef __cplusplus
#include <exception>
#include <string>
/* Pre-include the C++ headers whose declarations contain member functions
 * named open()/close() (std::messages facet in <locale>; basic_filebuf and
 * basic_*fstream in <fstream>). They MUST be parsed before the open/close
 * intercept macros are defined below, otherwise the macros rewrite those
 * member declarations. Subsequent re-includes hit include guards (no-op).
 * No TU uses std::fstream objects; this is purely to parse declarations. */
#include <locale>
#include <fstream>

class TippecanoeExitException : public std::exception {
public:
	int _code;
	std::string _file;
	int _line;
	explicit TippecanoeExitException(int code, std::string const &file = std::string(), int line = 0)
	    : _code(code), _file(file), _line(line) {}
	const char *what() const noexcept override {
		return "tippecanoe exit";
	}
};

#define exit(code) throw TippecanoeExitException((code), __FILE__, __LINE__)
#else
#define exit(code) (g_tc_exit_code = (code), longjmp(g_tc_exit_jmp, 1))
#endif

/* ---- fd registry API (C linkage, usable from C and C++) ---- */

#define TC_FD_PATH_MAX 256
#define TC_FD_SNAPSHOT_MAX 512

typedef struct tc_fd_info {
	int fd;
	char path[TC_FD_PATH_MAX];
	const char *file; /* open site __FILE__ (static lifetime) */
	int line;	  /* open site __LINE__ */
} tc_fd_info;

#ifdef __cplusplus
extern "C" {
#endif

uint64_t tc_run_begin(void);
void tc_run_end(uint64_t run_id, int report);

int   tc_open(const char *file, int line, const char *path, int flags, ...);
int   tc_close(const char *file, int line, int fd);
FILE *tc_fopen(const char *file, int line, const char *path, const char *mode);
int   tc_fclose(const char *file, int line, FILE *fp);
FILE *tc_fdopen(const char *file, int line, int fd, const char *mode);
int   tc_mkstemp(const char *file, int line, char *name);
int   tc_dup(const char *file, int line, int oldfd);
int   tc_pipe(const char *file, int line, int fds[2]);

/* Unregister without closing (for gzclose / ownership handoff). */
void tc_fd_forget(int fd);

/* Snapshot tippecanoe-owned FDs for the current run. Returns count written
 * (capped at out_cap). Each entry includes open site file:line and path. */
int tc_fd_snapshot(tc_fd_info *out, int out_cap);

/* Log FDs present in after but not before. Returns how many new owned FDs. */
int tc_fd_dump_new(const tc_fd_info *before, int n_before, const tc_fd_info *after, int n_after);

/* Supplement: log /proc/self/fd targets for fds in [fd_lo, fd_hi). */
void tc_fd_dump_proc_between(int fd_lo, int fd_hi);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
/* RAII guard: on scope exit (normal return or exception unwinding) reports
 * and closes any fd registered for this run that was not closed. */
class tc_run_guard {
	uint64_t rid;

public:
	explicit tc_run_guard(uint64_t id) : rid(id) {}
	~tc_run_guard();
};

/* RAII guard for a FILE* opened via fopen(): closes it on scope exit (normal
 * return or exception unwinding), matching the auto-close semantics of
 * std::fstream so a throw inside the guarded block does not leak the fd.
 * Calls tc_fclose() directly (not the fclose macro) so the fd is unregistered
 * from the global registry regardless of macro definition order. */
class tc_FILE_guard {
	FILE *fp;

public:
	explicit tc_FILE_guard(FILE *f) : fp(f) {}
	~tc_FILE_guard() {
		if (fp != NULL) {
			tc_fclose(__FILE__, __LINE__, fp);
			fp = NULL;
		}
	}

private:
	tc_FILE_guard(tc_FILE_guard const &);
	tc_FILE_guard &operator=(tc_FILE_guard const &);
};
#endif

/* ---- file descriptor intercept macros ----
 * Defined after the system headers (whose declarations are already parsed)
 * and after the tc_* declarations above. */
#define open(...)   tc_open(__FILE__, __LINE__, __VA_ARGS__)
#define close(fd)   tc_close(__FILE__, __LINE__, (fd))
#define fopen(...)  tc_fopen(__FILE__, __LINE__, __VA_ARGS__)
#define fclose(fp)  tc_fclose(__FILE__, __LINE__, (fp))
#define fdopen(...) tc_fdopen(__FILE__, __LINE__, __VA_ARGS__)
#define mkstemp(name) tc_mkstemp(__FILE__, __LINE__, (name))
#define dup(oldfd)  tc_dup(__FILE__, __LINE__, (oldfd))
#define pipe(fds)   tc_pipe(__FILE__, __LINE__, (fds))

#ifdef __ANDROID__
#define fprintf(fp, fmt, ...) tippecanoe_logf(1, fmt, ##__VA_ARGS__)
#define printf(fmt, ...) tippecanoe_logf(0, fmt, ##__VA_ARGS__)
#define perror(str) tippecanoe_logf(2, "perror: %s: %s", str, strerror(errno))
#endif

#endif /* __ANDROID__ || TIPPECANOE_VALIDATE */

#endif /* EXIT_UTIL_H */
