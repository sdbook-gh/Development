#ifndef PROGRESS_HOOK_H
#define PROGRESS_HOOK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*tippecanoe_progress_cb)(int percent, const char *stage);

/* Register a progress callback. Pass NULL to unregister.
 * Thread-safety is the caller's responsibility (single-flight lock). */
void tippecanoe_set_progress_callback(tippecanoe_progress_cb cb);
void tile_join_set_progress_callback(tippecanoe_progress_cb cb);
void tile_join_ext_set_progress_callback(tippecanoe_progress_cb cb);

/* Called from internal progress sites.
 * percent in [0,100], or -1 for indeterminate progress. */
void tippecanoe_report_progress(int percent, const char *stage);

/* tile-join / tile-join-ext: reset counter before dispatch_tasks, report per tile in join_worker. */
void tile_join_progress_reset(size_t total);
void tile_join_progress_tile(long long z, long long x, long long y);

#ifdef __cplusplus
}
#endif

#endif /* PROGRESS_HOOK_H */
