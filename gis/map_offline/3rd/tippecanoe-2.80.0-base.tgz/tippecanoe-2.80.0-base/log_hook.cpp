#include "log_hook.h"

#include <cstdarg>
#include <cstdio>
#include <cstring>

static tippecanoe_log_cb g_log_cb = 0;

static void forward_log(int level, const char *msg) {
	if (msg == NULL || msg[0] == '\0') {
		return;
	}
	if (strchr(msg, '\r') != NULL) {
		return;
	}
	if (g_log_cb) {
		g_log_cb(level, msg);
	}
}

extern "C" void tippecanoe_set_log_callback(tippecanoe_log_cb cb) {
	g_log_cb = cb;
}

extern "C" void tile_join_set_log_callback(tippecanoe_log_cb cb) {
	g_log_cb = cb;
}

extern "C" void tippecanoe_log(int level, const char *msg) {
	forward_log(level, msg);
}

extern "C" void tippecanoe_logf(int level, const char *fmt, ...) {
	char buf[1024];
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(buf, sizeof(buf), fmt, ap);
	va_end(ap);
	forward_log(level, buf);
}
