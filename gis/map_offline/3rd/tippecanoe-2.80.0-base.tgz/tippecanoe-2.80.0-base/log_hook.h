#ifndef LOG_HOOK_H
#define LOG_HOOK_H

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*tippecanoe_log_cb)(int level, const char *msg);

/* level: 0=INFO, 1=WARN, 2=ERROR */
void tippecanoe_set_log_callback(tippecanoe_log_cb cb);
void tile_join_set_log_callback(tippecanoe_log_cb cb);

void tippecanoe_log(int level, const char *msg);
void tippecanoe_logf(int level, const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* LOG_HOOK_H */
