#ifndef TILE_JOIN_EXT_H
#define TILE_JOIN_EXT_H

#ifdef __cplusplus
extern "C" {
#endif

/* Opaque context for tile-join-ext operations */
typedef struct tile_join_ext_ctx tile_join_ext_ctx;

/* Create a new tile-join-ext context */
tile_join_ext_ctx *tile_join_ext_create(void);

/* Add an input mbtiles/pmtiles/directory path */
int tile_join_ext_add_input(tile_join_ext_ctx *ctx, const char *path);

/* Set output mbtiles path */
int tile_join_ext_set_output(tile_join_ext_ctx *ctx, const char *path);

/* Set output directory path (mutually exclusive with set_output) */
int tile_join_ext_set_output_dir(tile_join_ext_ctx *ctx, const char *path);

/* Set option by key/value pair. Supported keys:
 *   "force"           - "1" to overwrite existing output
 *   "overzoom"        - "1" to enable overzoom
 *   "buffer"          - buffer size in pixels
 *   "if_matched"      - "1" to only keep matched features
 *   "attribution"     - attribution string
 *   "name"            - tileset name
 *   "description"     - tileset description
 *   "minzoom"         - minimum zoom level
 *   "maxzoom"         - maximum zoom level
 *   "csv"             - path to CSV join file
 *   "exclude"         - attribute to exclude (can be called multiple times)
 *   "include"         - attribute to include (can be called multiple times)
 *   "exclude_all"     - "1" to exclude all attributes by default
 *   "keep_layer"      - layer name to keep (can be called multiple times)
 *   "remove_layer"    - layer name to remove (can be called multiple times)
 *   "rename_layer"    - "old:new" layer rename (can be called multiple times)
 *   "feature_filter"  - JSON filter expression
 *   "feature_filter_file" - path to JSON filter file
 *   "no_tile_compression" - "1" to disable compression
 *   "no_tile_size_limit"  - "1" to disable 500KB limit
 *   "quiet"           - "1" for quiet mode
 *   "read_from"       - path to file listing input sources
 *   "boundary_only"   - "1" to only output tiles present in >= 2 input sources
 *   "drop_densest_as_needed" - "1" to drop densest features in oversized tiles
 */
int tile_join_ext_set_option(tile_join_ext_ctx *ctx, const char *key, const char *value);

/* Run the boundary tile join operation.
 * Returns 0 on success, non-zero on error. */
int tile_join_ext_run(tile_join_ext_ctx *ctx);

/* Destroy the context and free all resources */
void tile_join_ext_destroy(tile_join_ext_ctx *ctx);

#ifdef __cplusplus
}
#endif

#endif /* TILE_JOIN_EXT_H */
