#include "mydll.hpp"

void foo() {
    throw 0;
}
