#pragma once

extern "C" void foo();
